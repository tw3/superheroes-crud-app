An application for viewing and presenting a sequence of code examples.

Undertaken to learn Angular.js.

By Curran Kelleher 3/5/2014

https://github.com/curran/screencasts/tree/gh-pages/introToAngular/exampleViewer

I, Ted Weatherly, take no credit for credit for the code in this folder.  I am merely using Curran's useful code.