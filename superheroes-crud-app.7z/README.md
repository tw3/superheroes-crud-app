# superheroes-crud-app
Sample web app to create, read, update, and delete superheroes.
